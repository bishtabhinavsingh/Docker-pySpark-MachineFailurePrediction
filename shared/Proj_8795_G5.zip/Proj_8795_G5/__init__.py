import logging.config

import pandas as pd
import pyspark.sql.functions as F
from pyspark.ml.fpm import FPGrowth


from Proj_8795_G5.spark import get_spark, get_SQLContext
from Proj_8795_G5.utils import logging_init, logger
from Proj_8795_G5.basket import to_binary, ready_basket, analyze

import findspark

__version__ = "0.1.0"

logging.getLogger('Proj_8795_G5').addHandler(logging.NullHandler())
logging_init()

# https://stackoverflow.com/questions/53217767/py4j-protocol-py4jerror-org-apache-spark-api-python-pythonutils-getencryptionen
# Only necessary when running in Docker Python as a single node process (without entrypoint setup)
findspark.init()

data_path = "data.csv"

def main():
    logger().info("Start of Proj_8795_G5")
    logger().debug("Reading data")
    pdf = read_data(data_path)
    logger().debug("User input")
    print(pdf)

    logger().debug("Preparing data")
    df = prep_data(pdf)
    logger().debug("Creating model")
    cust_recom(df)

    logger().info("End of Proj_8795_G5")

def read_data(data_path):
    try:
        pd.read_csv(data_path)
    except Exception as e:
        logger().error("Cannot load data from path: " + str(e))
        exit(1)
    pdf = pd.read_csv(data_path, converters={i: str for i in range(100)})
    return (pdf)

def prep_data(pdf):
    #nums = {str(x) for x in range(100)}
    #repeat_words = {"pack", "set", "of", ".", "small", "large", "blue", "black", "green", "red", "yellow", "gold", "silver", "white"}
    pdf['Description'] = [str(word).lower() for word in pdf['Description']]
    #pdf['Description'] = pdf['Description'].apply(lambda x: ' '.join([word for word in x.split() if word not in repeat_words]))
    #pdf['Description'] = pdf['Description'].apply(lambda x: ' '.join([word for word in x.split() if word not in nums]))
    pdf['Description'] = [" ".join(str(x).split()) for x in pdf['Description']]
    #pdf['Description'] = [word for word in pdf['Description'] if not str(word) in repeat_words]
    pdf = pdf[['StockCode','CustomerID']]
    #print(pdf['StockCode'])
    print(pdf)
    pdf = pdf.groupby('StockCode').agg([('CustomerID', lambda x: list(set(x)))])
    #pdf["CustomerID"] = pdf.index
    #pdf.columns = ['CustomerID']
    #pdf['Description'] = [x.split(',') for x in pdf['Description']]
    print(pdf)
    df = get_SQLContext().createDataFrame(pdf)
    df.printSchema()
    #df.drop("InvoiceDate")
    #df.drop("Country")
    #df.drop('InvoiceNo')
    #df = df.withColumn('InvoiceNo', df['InvoiceNo'].cast('int'))
    #df = df.withColumn('StockCode', df['StockCode'].cast('string'))
    #df = df.withColumn('Description', df['Description'].cast('string'))
    #df = df.withColumn('Quantity', df['Quantity'].cast('int'))
    #df = df.withColumn('UnitPrice', df['UnitPrice'].cast('double'))
    #df = df.withColumn('CustomerID', df['CustomerID'].cast('int'))
    return (df)
def cust_recom(df):
    fpGrowth = FPGrowth(itemsCol="('CustomerID', 'CustomerID')", minSupport=0.1, minConfidence=0.1)
    model = fpGrowth.fit(df)
    model.freqItemsets.show()
    print("Model Asso Rules")
    model.associationRules.show()
    model.transform(df).show()
