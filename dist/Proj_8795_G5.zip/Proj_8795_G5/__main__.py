from Proj_8795_G5 import main

if __name__ == '__main__':
    main()
